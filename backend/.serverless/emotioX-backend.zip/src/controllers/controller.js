"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendTemporaryPassword = exports.refreshToken = exports.logoutUser = exports.loginUser = exports.updateUserById = exports.deleteUserById = exports.getUserById = exports.getAllUsers = exports.registerUser = void 0;
const client_ses_1 = require("@aws-sdk/client-ses");
const crypto_1 = __importDefault(require("crypto"));
const dotenv_1 = __importDefault(require("dotenv"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const argon2_1 = __importDefault(require("argon2"));
const database_1 = __importDefault(require("../config/database"));
const user_1 = __importDefault(require("../models/user"));
const mongoose_1 = __importDefault(require("mongoose"));
const temporaryPassword_1 = __importDefault(require("../models/temporaryPassword"));
dotenv_1.default.config();
const sesClient = new client_ses_1.SESClient({ region: "us-east-1" });
/**
 * Registers a new user in the database
 * @param event - AWS Lambda event object, expects user data in JSON format in the body
 * @returns The created user or an error message
 */
const registerUser = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Missing user data in request body' }),
            };
        }
        const { name, lastname, email, username, password } = JSON.parse(event.body);
        console.log('Event Body:', event.body);
        await (0, database_1.default)(); // Asegúrate de que la conexión a la DB esté activa
        // Verificar si ya existe un usuario con el mismo email
        const emailExists = await user_1.default.findOne({ email });
        if (emailExists) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Email already registered' }),
            };
        }
        // Verificar si ya existe un usuario con el mismo username
        const usernameExists = await user_1.default.findOne({ username });
        if (usernameExists) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Username already taken' }),
            };
        }
        // Hashear la contraseña usando argon2
        const hashedPassword = await argon2_1.default.hash(password);
        // Crear el nuevo usuario con la contraseña hasheada
        const newUser = await user_1.default.create({
            name,
            lastname,
            email,
            username,
            password: hashedPassword,
        });
        return {
            statusCode: 201,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: 'User registered successfully',
                userId: newUser._id, // Solo devolvemos datos mínimos necesarios
            }),
        };
    }
    catch (error) {
        console.error('Error registering user:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Registration failed' }),
        };
    }
};
exports.registerUser = registerUser;
/**
 * Retrieves all users from the database
 * @param event - AWS Lambda event object
 * @returns A list of all users or an error message
 */
const getAllUsers = async (event) => {
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        // Obtener todos los usuarios usando el modelo de Mongoose
        const users = await user_1.default.find({});
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(users),
        };
    }
    catch (error) {
        console.error('Error retrieving users:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to retrieve users' }),
        };
    }
};
exports.getAllUsers = getAllUsers;
/**
 * Retrieves a single user from the database by ID
 * @param event - AWS Lambda event object, expects an "id" parameter
 * @returns The user data or an error message
 */
const getUserById = async (event) => {
    var _a;
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        // Obtener el ID del usuario de los parámetros de la ruta
        const userId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!userId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User ID is required' }),
            };
        }
        // Verificar que el ID sea válido
        if (!mongoose_1.default.Types.ObjectId.isValid(userId)) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid user ID' }),
            };
        }
        // Buscar el usuario por ID usando el modelo de Mongoose
        const user = await user_1.default.findById(userId);
        if (!user) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User not found' }),
            };
        }
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user),
        };
    }
    catch (error) {
        console.error('Error retrieving user by ID:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to retrieve user' }),
        };
    }
};
exports.getUserById = getUserById;
/**
 * Deletes a user from the database by ID
 * @param event - AWS Lambda event object, expects an "id" parameter
 * @returns A success message or an error message
 */
const deleteUserById = async (event) => {
    var _a;
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        // Obtener el ID del usuario de los parámetros de la ruta
        const userId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!userId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User ID is required' }),
            };
        }
        // Verificar que el ID sea válido
        if (!mongoose_1.default.Types.ObjectId.isValid(userId)) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid user ID' }),
            };
        }
        // Eliminar el usuario por ID usando el modelo de Mongoose
        const deletedUser = await user_1.default.findByIdAndDelete(userId);
        if (!deletedUser) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User not found' }),
            };
        }
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'User deleted successfully', user: deletedUser }),
        };
    }
    catch (error) {
        console.error('Error deleting user by ID:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to delete user' }),
        };
    }
};
exports.deleteUserById = deleteUserById;
/**
 * Updates a user's data in the database by ID
 * @param event - AWS Lambda event object, expects an "id" parameter and user data in the body
 * @returns The updated user data or an error message
 */
const updateUserById = async (event) => {
    var _a;
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        // Obtener el ID del usuario de los parámetros de la ruta
        const userId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!userId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User ID is required' }),
            };
        }
        // Verificar que el ID sea válido
        if (!mongoose_1.default.Types.ObjectId.isValid(userId)) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid user ID' }),
            };
        }
        // Verificar si el cuerpo de la solicitud contiene datos
        if (!event.body) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Request body is required' }),
            };
        }
        // Parsear los datos del cuerpo
        const updatedData = JSON.parse(event.body);
        // Verificar si se está actualizando la contraseña
        if (updatedData.password) {
            updatedData.password = await argon2_1.default.hash(updatedData.password); // Hashear la nueva contraseña
        }
        // Buscar y actualizar el usuario
        const user = await user_1.default.findByIdAndUpdate(userId, updatedData, {
            new: true, // Devuelve el documento actualizado
            runValidators: true, // Ejecuta validaciones en los datos actualizados
        });
        if (!user) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User not found' }),
            };
        }
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'User updated successfully', user }),
        };
    }
    catch (error) {
        console.error('Error updating user by ID:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to update user' }),
        };
    }
};
exports.updateUserById = updateUserById;
/**
 * Authenticates a user based on username or email and password
 * @param event - AWS Lambda event object, expects username/email and password in the body
 * @returns A success message with user data or an error message
 */
const loginUser = async (event) => {
    try {
        if (!event.body) {
            throw new Error('Missing user data in request body');
        }
        const { identifier, password } = JSON.parse(event.body);
        await (0, database_1.default)();
        const user = (await user_1.default.findOne({ $or: [{ email: identifier }, { username: identifier }] }));
        if (!user) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User not found' }),
            };
        }
        const isPasswordValid = await argon2_1.default.verify(user.password, password);
        if (!isPasswordValid) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid password' }),
            };
        }
        // Convertir explícitamente _id a string
        const { accessToken, refreshToken } = generateTokens(user._id.toHexString());
        user.refreshToken = refreshToken;
        await user.save();
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                "Access-Control-Allow-Credentials": true,
            },
            body: JSON.stringify({
                message: 'Login successful',
                accessToken: `Bearer ${accessToken}`,
                refreshToken,
                user: {
                    id: user._id,
                    name: user.name,
                    lastname: user.lastname,
                    email: user.email,
                    username: user.username,
                },
            }),
        };
    }
    catch (error) {
        console.error('Error during login:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Login failed' }),
        };
    }
};
exports.loginUser = loginUser;
/**
 * Logs out a user by updating their last session and optionally revoking the token
 * @param event - AWS Lambda event object
 * @returns A success message or an error message
 */
const logoutUser = async (event) => {
    try {
        await (0, database_1.default)();
        // Obtener el token de autorización del encabezado y eliminar el prefijo "Bearer "
        const authHeader = event.headers.Authorization || event.headers.authorization;
        const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
        if (!token) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Authorization token is required' }),
            };
        }
        // Decodificar el token para extraer el ID del usuario
        const decodedToken = decodeToken(token);
        const userId = decodedToken === null || decodedToken === void 0 ? void 0 : decodedToken.id;
        if (!userId || !mongoose_1.default.Types.ObjectId.isValid(userId)) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid token or user ID' }),
            };
        }
        // Buscar el usuario por ID y actualizar su última sesión
        const user = await user_1.default.findByIdAndUpdate(userId, { lastSession: new Date() }, { new: true });
        if (!user) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'User not found' }),
            };
        }
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Logout successful', user: { id: user._id, lastSession: user.lastSession } }),
        };
    }
    catch (error) {
        console.error('Error during logout:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to logout' }),
        };
    }
};
exports.logoutUser = logoutUser;
// Función refresh token
const refreshToken = async (event) => {
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        const { refreshToken } = JSON.parse(event.body || '{}');
        console.log('refreshToken: ', refreshToken);
        if (!refreshToken) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Refresh token is required' }),
            };
        }
        // Verificar el refresh token
        console.log('Verificando ...');
        const decoded = jsonwebtoken_1.default.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'mi_refresh_secreto');
        console.log('decodificando ...', decoded.id);
        const user = await user_1.default.findById(decoded.id);
        console.log('Decodificado: ', user);
        if (!user || user.refreshToken !== refreshToken) {
            return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Invalid refresh token' }),
            };
        }
        // Generar nuevo access token
        const newAccessToken = jsonwebtoken_1.default.sign({ id: user._id }, process.env.JWT_SECRET || 'access_secret', { expiresIn: '15m' });
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accessToken: newAccessToken }),
        };
    }
    catch (error) {
        console.error('Error refreshing token:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Failed to refresh token' }),
        };
    }
};
exports.refreshToken = refreshToken;
// Función para decodificar el token
const decodeToken = (token) => {
    try {
        const jwtSecret = process.env.JWT_SECRET || 'mi_secreto';
        if (!jwtSecret) {
            console.error('JWT_SECRET not defined');
            return null;
        }
        const decoded = jsonwebtoken_1.default.verify(token, jwtSecret);
        return decoded;
    }
    catch (error) {
        console.error('Invalid token');
        return null;
    }
};
// Función para generar access token y refresh token
const generateTokens = (userId) => {
    const accessToken = jsonwebtoken_1.default.sign({ id: userId }, process.env.JWT_SECRET || 'mi_secreto', { expiresIn: '15m' } // access token expira en 15 minutos
    );
    const refreshToken = jsonwebtoken_1.default.sign({ id: userId }, process.env.JWT_REFRESH_SECRET || 'mi_refresh_secreto', { expiresIn: '7d' } // refresh token expira en 7 días
    );
    return { accessToken, refreshToken };
};
function generateTemporaryPassword(length = 8) {
    return crypto_1.default.randomBytes(length).toString('hex');
}
// Función para enviar la contraseña temporal y guardarla en la base de datos
const sendTemporaryPassword = async (event) => {
    try {
        await (0, database_1.default)();
        // Parseamos el body para obtener la dirección de correo
        const { email } = JSON.parse(event.body || "{}");
        if (!email) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: "El campo 'email' es requerido en el cuerpo de la solicitud" }),
            };
        }
        // Generamos una contraseña temporal
        const temporaryPassword = generateTemporaryPassword(8);
        // Guardamos o actualizamos la contraseña temporal en la base de datos
        await temporaryPassword_1.default.findOneAndUpdate({ email }, // Buscamos por email
        { email, temporaryPassword, createdAt: new Date() }, // Actualizamos la contraseña y fecha de creación
        { upsert: true, new: true } // Si no existe, creamos un nuevo documento
        );
        // Configuramos los parámetros del correo
        const params = {
            Destination: {
                ToAddresses: [email], // Usamos el correo proporcionado por el cliente
            },
            Message: {
                Body: {
                    Text: { Data: `Tu contraseña temporal es: ${temporaryPassword}. Esta contraseña es válida por 15 minutos.` },
                },
                Subject: { Data: "Tu contraseña temporal de EmotioX" },
            },
            Source: "carriagadafalcone@gmail.com", // Cambia a tu dirección verificada en SES
        };
        // Enviamos el correo usando SES
        const command = new client_ses_1.SendEmailCommand(params);
        await sesClient.send(command);
        // Respuesta exitosa
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Correo enviado exitosamente",
            }),
        };
    }
    catch (error) {
        console.error("Error al enviar correo:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error al enviar correo" }),
        };
    }
};
exports.sendTemporaryPassword = sendTemporaryPassword;
