"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createResearchWithImages = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const database_1 = __importDefault(require("../config/database"));
const researchCreation_1 = __importDefault(require("../models/researchCreation"));
const project_1 = __importDefault(require("../models/project"));
/**
 * Tipos de investigación que requieren imágenes.
 */
const researchTypesRequiringImages = ['TypeWithImages1', 'TypeWithImages2'];
/**
 * Controlador para crear un nuevo documento de investigación, opcionalmente manejando imágenes previamente almacenadas.
 */
const createResearchWithImages = async (event) => {
    try {
        // Conectar a la base de datos
        await (0, database_1.default)();
        // Validar el cuerpo de la solicitud
        if (!event.body) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Request body is required' }),
            };
        }
        const data = JSON.parse(event.body);
        const { researchName, enterpriseName, selectedResearchType, selectedResearchModule, uploadedFiles, // Lista de URLs de archivos ya almacenados en S3
        selectedProjects, moduleDetails, } = data;
        // Validar campos requeridos
        if (!researchName || !enterpriseName || !selectedResearchType || !selectedResearchModule) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing required fields' }),
            };
        }
        // Validar imágenes si el tipo de investigación las requiere
        if (researchTypesRequiringImages.includes(selectedResearchType)) {
            if (!uploadedFiles || !Array.isArray(uploadedFiles) || uploadedFiles.length === 0) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Uploaded files are required for this type of research' }),
                };
            }
            const invalidFiles = uploadedFiles.filter((file) => typeof file !== 'string' || !file.startsWith('https://'));
            if (invalidFiles.length > 0) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Invalid URLs in uploadedFiles', invalidFiles }),
                };
            }
        }
        // Validar que los proyectos referenciados existen en la base de datos
        if (selectedProjects && selectedProjects.length > 0) {
            const projectIds = selectedProjects.map((id) => new mongoose_1.default.Types.ObjectId(id));
            const existingProjects = await project_1.default.find({ _id: { $in: projectIds } });
            if (existingProjects.length !== projectIds.length) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Some projects do not exist', selectedProjects }),
                };
            }
        }
        // Crear el documento en MongoDB
        const newResearch = await researchCreation_1.default.create({
            researchName,
            enterpriseName,
            selectedResearchType,
            selectedResearchModule,
            uploadedFiles: uploadedFiles || [],
            selectedProjects: selectedProjects || [],
            researchTypeSpecificData: moduleDetails || {},
        });
        // Realizar un "populate" para expandir referencias
        const populatedResearch = await researchCreation_1.default.findById(newResearch._id)
            .populate('selectedProjects') // Expande las referencias de Project
            .exec();
        return {
            statusCode: 201,
            body: JSON.stringify({
                message: 'Research created successfully',
                research: populatedResearch || newResearch,
            }),
        };
    }
    catch (error) {
        console.error('Error creating research:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to create research',
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.createResearchWithImages = createResearchWithImages;
