"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.disconnectHandler = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const database_1 = __importDefault(require("../config/database"));
// Modelo de MongoDB para almacenar los connectionIds
const ConnectionSchema = new mongoose_1.default.Schema({
    connectionId: { type: String, required: true, unique: true },
    connectedAt: { type: Date, default: Date.now },
});
const Connection = mongoose_1.default.model('Connection', ConnectionSchema);
/**
 * Handler para gestionar la desconexión de WebSocket.
 * Elimina el `connectionId` de MongoDB cuando el cliente se desconecta.
 */
const disconnectHandler = async (event) => {
    const { connectionId } = event.requestContext;
    try {
        // Conectar a MongoDB
        await (0, database_1.default)();
        // Eliminar el connectionId de MongoDB
        const result = await Connection.findOneAndDelete({ connectionId });
        if (result) {
            console.log('Connection deleted:', connectionId);
        }
        else {
            console.log('Connection not found for deletion:', connectionId);
        }
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Disconnected.',
                connectionId,
                deleted: !!result,
            }),
        };
    }
    catch (error) {
        console.error('Error deleting connection ID:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to disconnect.',
                error: (error instanceof Error) ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.disconnectHandler = disconnectHandler;
