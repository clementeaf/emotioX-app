"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshHandler = void 0;
const aws_sdk_1 = require("aws-sdk");
const mongoose_1 = __importDefault(require("mongoose"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = __importDefault(require("../config/database"));
// Definición del esquema para las conexiones WebSocket
const ConnectionSchema = new mongoose_1.default.Schema({
    connectionId: { type: String, required: true, unique: true },
    connectedAt: { type: Date, default: Date.now },
});
const Connection = mongoose_1.default.model("Connection", ConnectionSchema);
const refreshHandler = async (event) => {
    try {
        // Validar que el endpoint esté configurado
        const websocketEndpoint = process.env.WEBSOCKET_ENDPOINT;
        console.log("WebSocket Endpoint:", websocketEndpoint);
        if (!websocketEndpoint) {
            throw new Error("WebSocket endpoint is not configured in the environment variables");
        }
        // Crear cliente de API Gateway para WebSocket
        const apiGateway = new aws_sdk_1.ApiGatewayManagementApi({
            endpoint: websocketEndpoint,
        });
        // Conectar a MongoDB
        await (0, database_1.default)();
        // Obtener todas las conexiones activas
        const connections = await Connection.find({});
        console.log("Active connections:", connections.length);
        // Generar un nuevo token de acceso
        const accessToken = jsonwebtoken_1.default.sign({ message: "New Access Token" }, process.env.JWT_SECRET || "default_secret", {
            expiresIn: "15m",
        });
        // Enviar el token a cada conexión activa
        const sendPromises = connections.map(async (connection) => {
            try {
                await apiGateway
                    .postToConnection({
                    ConnectionId: connection.connectionId,
                    Data: JSON.stringify({ accessToken }),
                })
                    .promise();
                console.log(`Token sent to connection ${connection.connectionId}`);
            }
            catch (error) {
                if (error instanceof Error) {
                    console.error(`Error sending message to ${connection.connectionId}:`, error.message);
                    // Opcional: Eliminar conexiones inválidas
                    if (error.statusCode === 410) {
                        console.log(`Connection ${connection.connectionId} is stale and will be removed.`);
                        await Connection.deleteOne({ connectionId: connection.connectionId });
                    }
                    else {
                        console.log(`Error for connection ${connection.connectionId}:`, error);
                    }
                }
                else {
                    console.error(`Error sending message to ${connection.connectionId}: Unknown error`);
                }
            }
        });
        await Promise.all(sendPromises);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Tokens sent successfully",
                connections: connections.length,
            }),
        };
    }
    catch (error) {
        console.error("Error sending tokens:", error);
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to send tokens",
                error: errorMessage,
            }),
        };
    }
};
exports.refreshHandler = refreshHandler;
