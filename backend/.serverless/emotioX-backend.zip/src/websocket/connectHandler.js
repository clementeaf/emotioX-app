"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectHandler = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const database_1 = __importDefault(require("../config/database"));
// Define un modelo de MongoDB para almacenar los connectionIds
const ConnectionSchema = new mongoose_1.default.Schema({
    connectionId: { type: String, required: true, unique: true },
    connectedAt: { type: Date, default: Date.now },
});
const Connection = mongoose_1.default.model('Connection', ConnectionSchema);
/**
 * Handler para gestionar la conexión de WebSocket.
 * Almacena el `connectionId` en DynamoDB para futuras interacciones.
 */
const connectHandler = async (event) => {
    const { connectionId } = event.requestContext;
    try {
        // Conectar a MongoDB
        await (0, database_1.default)();
        // Guardar el connectionId en DynamoDB
        const newConnection = new Connection({ connectionId });
        const savedConnection = await newConnection.save();
        console.log('Connection saved:', savedConnection);
        console.log('Connection successful:', connectionId, savedConnection);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Connected.',
                connectionId: connectionId,
                savedConnection,
            }),
        };
    }
    catch (error) {
        console.error('Error storing connection ID:', error);
        return {
            statusCode: 500,
            body: 'Failed to connect.',
        };
    }
};
exports.connectHandler = connectHandler;
